# 0.3.0

Add `g:ctrlp_tjump_skip_tag_name` to skip tag name (thanks @Konfekt)

# 0.2.0

Support all CtrlP file open modes (current window, new tab, vertical split, horizontal split)

# 0.1.0

* Add CtrlPtjumpVisual command to go to declaration of the selected text
* Bugfixes.
